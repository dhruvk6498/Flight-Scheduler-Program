/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flightschedulerdpk5267;


import java.util. * ;
import java.sql. *;

/**
 *
 * @author dhruvkakran
 */
public class Booking {
    
    private static PreparedStatement selectBookings;
    private static PreparedStatement countBookings;
    private static PreparedStatement addBooking;
    private static PreparedStatement dropBookings;
    private static PreparedStatement cancelBooking;
    private static PreparedStatement getCustomers;
    private static PreparedStatement checkForBooking;
    private static PreparedStatement checkForPassenger;
    private static PreparedStatement getFlightforBooking;
    private static PreparedStatement getPassenger;
    private static ResultSet resultSet;
    private static ResultSet dropResults;
    
    public static void addBooking(String PassengerName, String Date, String Flight){
        try{
            
            addBooking = DBConnection.getConnection().prepareStatement("INSERT INTO BOOKINGS VALUES (?,?,?)");
            addBooking.setString(1,PassengerName);
            addBooking.setString(2,Date);
            addBooking.setString(3,Flight);
            addBooking.executeUpdate();
            
        }
        
        catch (SQLException exception){
            
            exception.printStackTrace();
            System.exit(1);
        }
    }
    
    public static ArrayList<String> getCustomerInfo(String PassengerName){
        ArrayList<String> customerInfo = new ArrayList<String>();
        try{
            
            getPassenger = DBConnection.getConnection().prepareStatement("SELECT DATE, FLIGHT FROM BOOKINGS WHERE PASSENGER LIKE ?");
            getPassenger.setString(1,PassengerName);
            resultSet = getPassenger.executeQuery();
            while(resultSet.next()){
                
                String info = "";
                String flight = resultSet.getString("FLIGHT");
                String day = resultSet.getString("DATE");
                info = "BOOKED FOR FLIGHT " + flight + " ON " + day;
                customerInfo.add(info);
            }
        }
        catch(SQLException exception){
            
            exception.printStackTrace();
            System.exit(1);
        }
        
        return customerInfo;
    }
    
    
    public static ArrayList<String> dropFlightAndRebook(String FlightName, ArrayList<String> FlightList){
        ArrayList<String> customerStatus = new ArrayList<String>();
        Boolean customerRebooked = false;
        try{
            
            getCustomers = DBConnection.getConnection().prepareStatement("SELECT PASSENGER, DATE FROM BOOKINGS WHERE FLIGHT LIKE ?");
            getCustomers.setString(1, FlightName);
            dropResults = getCustomers.executeQuery();
            while(dropResults.next()){
                customerRebooked = false;
                String customer = dropResults.getString("PASSENGER");
                String day = dropResults.getString("DATE");
                
                for (String flight: FlightList){
                    
                    if(getBookingsForFlight(flight, day) < FlightInfo.getMaxSeatsforFlight(flight) && !Objects.equals(flight, FlightName)){
                        
                        addBooking(customer,day,flight);
                        customerStatus.add(customer + " REBOOKED ON FLIGHT " + flight + " ON DAY " + day);
                        customerRebooked = true;
                        break;
                    }
                }
                if (customerRebooked == false){
                    customerStatus.add(customer + " COULD NOT BE REBOOKED ON " + day);
                }
                
            }
            
            dropBookings = DBConnection.getConnection().prepareStatement("DELETE FROM BOOKINGS WHERE FLIGHT LIKE ?");
            dropBookings.setString(1,FlightName);
            dropBookings.executeUpdate();
            
        }
        catch(SQLException exception){
            
            exception.printStackTrace();
            System.exit(1);
        }
        
        return customerStatus;
    }
    
    public static String getFlightforCustomer(String PassengerName, String Date){
        String flightName = "";
        try{
            getFlightforBooking = DBConnection.getConnection().prepareStatement("SELECT FLIGHT FROM BOOKINGS WHERE PASSENGER LIKE ? AND DATE LIKE ?");
            getFlightforBooking.setString(1, PassengerName);
            getFlightforBooking.setString(2,Date);
            resultSet = getFlightforBooking.executeQuery();
            if (resultSet.next()){
                
                flightName = resultSet.getString("FLIGHT");
                
            }
            
        }catch(SQLException exception){
            exception.printStackTrace();
            System.exit(1);
            
        }
        return flightName;
        
    }
    
    public static void cancelBooking(String PassengerName, String Date){
        try{
            cancelBooking = DBConnection.getConnection().prepareStatement("DELETE FROM BOOKINGS WHERE PASSENGER LIKE ? AND DATE LIKE ?");
            cancelBooking.setString(1,PassengerName);
            cancelBooking.setString(2,Date);
            cancelBooking.executeUpdate();
            
            
        }catch (SQLException exception){
           exception.printStackTrace();
           System.exit(1);
        }
    }
    
    
    public static Boolean isPassengerOnList(String PassengerName){
        Boolean toreturn = false;
        
        try{
            
            checkForPassenger = DBConnection.getConnection().prepareStatement("SELECT * FROM BOOKINGS WHERE PASSENGER LIKE ?");
            checkForPassenger.setString(1,PassengerName);
            resultSet = checkForPassenger.executeQuery();
            if (resultSet.next()){
                
                toreturn = true;
            }
        }
        catch(SQLException exception){
            exception.printStackTrace();
            System.exit(1);
            
        }
        
        return toreturn;
    }
    
    public static ArrayList<String> getBookingListStatus(String Flight, String Date){
        
        ArrayList<String> statusList = new ArrayList<String>();
        String status = "";
        String passenger = "";
        String flight = "";
        String date = "";
        
        try{
            
            selectBookings = DBConnection.getConnection().prepareStatement("SELECT * FROM BOOKINGS WHERE FLIGHT LIKE ? AND DATE = ?");
            selectBookings.setString(1, Flight);
            selectBookings.setString(2, Date);
            resultSet = selectBookings.executeQuery();
            while (resultSet.next()){
                
                passenger = resultSet.getString("PASSENGER");
                flight = resultSet.getString("FLIGHT");
                date = resultSet.getString("DATE");
                status = passenger + " BOOKED FOR " + date + " ON FLIGHT " + flight;
                statusList.add(status);
            }
        }
        
        catch(SQLException exception){
            
            exception.printStackTrace();;
            System.exit(1);
        }
        
        return statusList;
        
    }
    public static int getBookingsForFlight(String Flight, String Date){
        
        int numberOfBookings = 0;
        
        try{
            
            countBookings = DBConnection.getConnection().prepareStatement("SELECT COUNT(*) FROM BOOKINGS WHERE FLIGHT LIKE ? AND DATE LIKE ?");
            countBookings.setString(1, "%" + Flight + "%");
            countBookings.setString(2, "%" + Date + "%");
            resultSet = countBookings.executeQuery();
            resultSet.next();
            numberOfBookings = resultSet.getInt(1);
        }
        
        catch(SQLException exception){
            
            exception.printStackTrace();
            System.exit(1);
        }
        return numberOfBookings;
    }
    
    public static Boolean doesBookingExist(String PassengerName, String Date){
        
        Boolean toreturn = false;
        
        try{
            checkForBooking = DBConnection.getConnection().prepareStatement("SELECT PASSENGER FROM BOOKINGS WHERE PASSENGER LIKE ? AND DATE LIKE ?");
            checkForBooking.setString(1,PassengerName);
            checkForBooking.setString(2,Date);
            resultSet = checkForBooking.executeQuery();
            if (resultSet.next()){
                
                toreturn = true;
            }
          
        }
        catch (SQLException exception){
            
            exception.printStackTrace();
            System.exit(1);
        }
        return toreturn;
    }
}
