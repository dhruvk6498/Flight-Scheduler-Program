/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flightschedulerdpk5267;

import java.sql. * ;


/**
 *
 * @author dhruvkakran
 */
public class DBConnection {
    
    private static final String URL = "jdbc:derby://localhost:1527/FlightSchedulerDBdpk5267";
    private static String USERNAME = "java";
    private static String PASSWORD = "java";
    
    private static Connection connection;
    
    
    
    public static Connection getConnection(){
        
        try{
            
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            connection = DriverManager.getConnection(URL, USERNAME,PASSWORD);
        } catch (SQLException exception){
            
            exception.printStackTrace();
            System.exit(1);
        } catch (ClassNotFoundException classNotFoundException){
            
            classNotFoundException.printStackTrace();
            System.exit(1);
            
        }
        
        return connection;
        
        
    }
    
}
