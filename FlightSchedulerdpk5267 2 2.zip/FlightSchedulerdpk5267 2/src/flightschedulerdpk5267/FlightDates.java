/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flightschedulerdpk5267;

import java.sql.*;
import java.util. *;

/**
 *
 * @author dhruvkakran
 */
public class FlightDates {
    
    private static PreparedStatement selectDates;
    private static PreparedStatement checkforDate;
    private static PreparedStatement addDates;
    private static ArrayList<String> dateList;
    private static ResultSet resultSet;
    
    
    public static ArrayList<String> getDates(){
        
        dateList = new ArrayList<>();
        
        try{
            
            selectDates = DBConnection.getConnection().prepareStatement("SELECT * FROM FLIGHTDATES");
            resultSet = selectDates.executeQuery();
            while(resultSet.next()){
                
                dateList.add(resultSet.getString(1));
            }
        } catch (SQLException exception){
            
            exception.printStackTrace();
            System.exit(1);
        }
        
        return dateList;
        
        
    }
    
    public static Boolean doesDayExist(String Date){
        Boolean toReturn = false;
        try{
            checkforDate = DBConnection.getConnection().prepareStatement("SELECT * FROM FLIGHTDATES WHERE DATE LIKE ?");
            checkforDate.setString(1, Date);
            resultSet = checkforDate.executeQuery();
            if (resultSet.next()){
                toReturn = true;
                
                
            }
        }catch(SQLException exception){
            
            exception.printStackTrace();
            System.exit(1);
        }
        return toReturn;
    }
    
    public static void addDay(String Date){
        
        try{
            
            addDates = DBConnection.getConnection().prepareStatement("INSERT INTO FLIGHTDATES VALUES (?)");
            addDates.setString(1,Date);
            addDates.executeUpdate();
        }
        
        catch (SQLException exception){
            
            exception.printStackTrace();
            System.exit(1);
        }
    }
   
}
    
