/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flightschedulerdpk5267;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author dhruvkakran
 */
public class FlightInfo {
    
    private static PreparedStatement selectFlights;
    private static PreparedStatement selectSeats;
    private static PreparedStatement addFlight;
    private static PreparedStatement dropFlight;
    private static PreparedStatement checkforFlight;
    private static ArrayList<String> flightList;
    private static ResultSet resultSet;
    
    public static ArrayList<String> getFlights(){
        
        
        flightList = new ArrayList<>();
        try {
            
            selectFlights = DBConnection.getConnection().prepareStatement("SELECT NAME FROM FLIGHTINFO");
            resultSet = selectFlights.executeQuery();
            while (resultSet.next()){
                
                flightList.add(resultSet.getString("NAME"));
                
            }
        } catch (SQLException exception){
            
            exception.printStackTrace();
            System.exit(1);
        }
        
        return flightList;
        
        
    }
    
    public static int getMaxSeatsforFlight(String FlightName){
        
        int flightSeats = 0;
        
        try{
            
            selectSeats = DBConnection.getConnection().prepareStatement("SELECT MAXSEATS FROM FLIGHTINFO WHERE NAME LIKE ?");
            selectSeats.setString(1, FlightName);
            resultSet = selectSeats.executeQuery();   
            
            if (resultSet.next()){
                
                flightSeats = resultSet.getInt("MAXSEATS");
                
            }
            
        }
         catch(SQLException exception){
             
             exception.printStackTrace();
             System.exit(1);
         }
        
        
        return flightSeats;
        
    }
    
    public static Boolean doesFlightExist(String FlightName){
        Boolean toReturn = false;
        try{
            checkforFlight = DBConnection.getConnection().prepareStatement("SELECT * FROM FLIGHTINFO WHERE NAME LIKE ?");
            checkforFlight.setString(1, FlightName);
            resultSet = checkforFlight.executeQuery();
            if (resultSet.next()){
                toReturn = true;
                
                
            }
        }catch(SQLException exception){
            
            exception.printStackTrace();
            System.exit(1);
        }
        return toReturn;
    }
        
    
    public static void addFlight(String FlightName, int MaxSeats){
        
        try{
            
            addFlight = DBConnection.getConnection().prepareStatement("INSERT INTO FLIGHTINFO VALUES (?,?)");
            addFlight.setString(1,FlightName);
            addFlight.setInt(2,MaxSeats);
            addFlight.executeUpdate();
            
            
        }
        catch (SQLException exception){
            
            exception.printStackTrace();
            System.exit(1);
        }
    }
    
    public static void dropFlight(String Flight){
        
        try{
            dropFlight = DBConnection.getConnection().prepareStatement("DELETE FROM FLIGHTINFO WHERE NAME LIKE ?");
            dropFlight.setString(1,Flight);
            dropFlight.executeUpdate();
        }
        catch(SQLException exception){
            exception.printStackTrace();
            System.exit(1);
            
            
        }
    }
                
                    
}
