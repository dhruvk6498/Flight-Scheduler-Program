
package flightschedulerdpk5267;

import java.awt. * ;
import java.sql. *;
import java.util. *;
import javax.swing.JFrame;

/**
 *
 * @author dhruvkakran
 */
public class FlightScheduler {

    
    public static void main(String[] args) {
        
        
        FlightSchedulerUI app = new FlightSchedulerUI();
        app.setSize(900,700);
        app.setVisible(true);
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
        /*
        String day1 = "2017-04-06";
        String day2 = "2017-04-08";
        
        System.out.println(FlightDates.getDates());
        System.out.println(FlightInfo.getFlights());
        WaitList.addWaitListEntry("Dhruv Kakran", "2017-04-06", "F101");
        WaitList.addWaitListEntry("Seema Kakran", "2017-04-06", "F101");
        System.out.println(WaitList.getWaitListStatus(day1));
        System.out.println(WaitList.getWaitListLength("F101", day1));
        Booking.addBooking("Dhruv Kakran", "2017-04-06", "F101");
        System.out.println(Booking.getBookingListStatus("F101", "2017-04-06"));
        Booking.addBooking("Seema Kakran", "2017-04-06", "F101");
        Booking.addBooking("Pradyumn Mattu", "2017-12-12", "G102");
        System.out.println(Booking.getBookingsForFlight("F101", "2017-04-06"));
        System.out.println(Booking.getBookingListStatus("F101", "2017-04-06"));
        System.out.println(Booking.getBookingListStatus("G102", "2017-12-12"));
        System.out.println(Booking.getBookingsForFlight("F101", "2017-04-06"));
        System.out.println(Booking.getBookingsForFlight("G102", "2017-12-12"));
        System.out.println(FlightInfo.getMaxSeatsforFlight("G102"));
        System.out.println(Booking.doesBookingExist("Dhruv Kakran", "2017-04-06")); 
        */
        //System.out.println(Booking.dropFlightAndRebook("G102", FlightInfo.getFlights()));
        
        
        

    }
    
}
