/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flightschedulerdpk5267;


import java.sql. * ;
import java.util. *;

public class WaitList {
    
    private static PreparedStatement addEntry;
    private static PreparedStatement selectEntries;
    private static PreparedStatement checkforEntry;
    private static PreparedStatement checkForPassenger;
    private static PreparedStatement cancelWait;
    private static PreparedStatement dropEntries;
    private static PreparedStatement getFirstCustomer;
    private static PreparedStatement checkCustomerFlight;
    private static PreparedStatement getCustomerPosition;
    private static PreparedStatement updateWaitList;
    private static PreparedStatement getPassenger;
    private static ResultSet resultSet;
    private static ResultSet waitListLength;
    
    public static ArrayList<String> getWaitListStatus(String Date){
        
        
        ArrayList<String> statusList = new ArrayList<String>();
        String status = new String();
        String name = "";
        String flight = "";
        String date = "";
        String position = "";
        
        try{
            
            selectEntries = DBConnection.getConnection().prepareStatement("SELECT * FROM WAITLIST WHERE DATE LIKE ? ");
            selectEntries.setString(1, "%" + Date + "%");
            resultSet = selectEntries.executeQuery();
            while(resultSet.next()){
                
                name = resultSet.getString("PASSENGER");
                flight = resultSet.getString("FLIGHT");
                date = resultSet.getString("DATE");
                position = resultSet.getString("POSITION");
                status = name + " FLYING " + flight + " on  " + date + "  AT WAIT LIST POSITION " + position;
                statusList.add(status);
                
            }           
        }
        
        catch (Exception exception){
            
            exception.printStackTrace();
            System.exit(1);
        }
        
        
        return statusList;
    }
    
    
    public static ArrayList<String> getCustomerInfo(String PassengerName){
        
        ArrayList<String> customerInfo = new ArrayList<String>();
        try{
            
            getPassenger = DBConnection.getConnection().prepareStatement("SELECT DATE, FLIGHT,POSITION FROM WAITLIST WHERE PASSENGER LIKE ?");
            getPassenger.setString(1,PassengerName);
            resultSet = getPassenger.executeQuery();
            while(resultSet.next()){
                
                String info = "";
                String flight = resultSet.getString("FLIGHT");
                String day = resultSet.getString("DATE");
                String position = resultSet.getString("POSITION");
                info = "ON WAITLIST FOR FLIGHT " + flight + " ON " + day + " AT WAITLIST POSITION " + position;
                customerInfo.add(info);
            }
        }
        catch(SQLException exception){
            
            exception.printStackTrace();
            System.exit(1);
        }
        
        return customerInfo;
    }
    
    public static void cancelWaiting(String PassengerName, String Date){
        try{
            checkCustomerFlight = DBConnection.getConnection().prepareStatement("SELECT FLIGHT, POSITION FROM WAITLIST WHERE PASSENGER LIKE ? AND DATE LIKE ?");
            cancelWait = DBConnection.getConnection().prepareStatement("DELETE FROM WAITLIST WHERE PASSENGER LIKE ? AND DATE LIKE ?");
            cancelWait.setString(1, PassengerName);
            cancelWait.setString(2,Date);
            checkCustomerFlight.setString(1,PassengerName);
            checkCustomerFlight.setString(2,Date);
            resultSet = checkCustomerFlight.executeQuery();
            resultSet.next();
            String flightName = resultSet.getString("FLIGHT");
            int customerPosition = resultSet.getInt("POSITION");
            cancelWait.executeUpdate();
            if (getWaitListLength(flightName, Date) != 0){
                WaitList.updateWaitListforFlight(flightName, Date, customerPosition);
            }
            
        }catch(SQLException exception){
            exception.printStackTrace();
            System.exit(1);
        }
        
        
    }
    
    
   
    
    public static Boolean isCustomerOnList(String PassengerName){
        Boolean toreturn = false;
        try{
            
            checkForPassenger = DBConnection.getConnection().prepareStatement("SELECT * FROM WAITLIST WHERE PASSENGER LIKE ?");
            checkForPassenger.setString(1, PassengerName);
            resultSet = checkForPassenger.executeQuery();
            if (resultSet.next()){
                
                toreturn = true;
            }
            else{
                
                toreturn = false;
            }
        }
        catch(SQLException exception){
            exception.printStackTrace();
            System.exit(1);
        }
        
        return toreturn;
    }
    
    public static void dropWaitsForFlight(String Flight){
        try{
            dropEntries = DBConnection.getConnection().prepareStatement("DELETE FROM WAITLIST WHERE FLIGHT LIKE ?");
            dropEntries.setString(1,Flight);    
            dropEntries.executeUpdate();
            
        }catch (SQLException exception){
            exception.printStackTrace();
            System.exit(1);
        }
    }
    
    
    public static void addWaitListEntry(String PassengerName, String Date, String Flight){
        
        int currentPosition = getWaitListLength(Flight,Date);
        
        try{
            
            addEntry = DBConnection.getConnection().prepareStatement("INSERT INTO WAITLIST VALUES (?,?,?,?)");
            addEntry.setString(1, PassengerName);
            addEntry.setString(2, Date);
            addEntry.setString(3, Flight);
            addEntry.setInt(4, currentPosition + 1);
            addEntry.executeUpdate();
        }
        
        
        
        catch (SQLException exception){
            
            exception.printStackTrace();
            System.exit(1);
        }
    }
    
    public static String getFirstCustomerWaiting(String Flight, String Day){
        String customerName = "";
        try{
            getFirstCustomer = DBConnection.getConnection().prepareStatement("SELECT PASSENGER FROM WAITLIST WHERE FLIGHT LIKE ? AND DATE LIKE ? AND POSITION = ?");
            getFirstCustomer.setString(1, Flight);
            getFirstCustomer.setString(2,Day);
            getFirstCustomer.setInt(3, 1);
            resultSet = getFirstCustomer.executeQuery();
            while (resultSet.next()){
                
                customerName = resultSet.getString("PASSENGER");
                
            }
        }catch(SQLException exception){
            
            exception.printStackTrace();
            System.exit(1);
        }
        return customerName;
    }
    
    public static void updateWaitListforFlight(String Flight, String Day, int Position){
        
        try{
            updateWaitList = DBConnection.getConnection().prepareStatement("UPDATE WAITLIST SET POSITION = POSITION - 1 WHERE POSITION > ? AND FLIGHT LIKE ? AND DATE LIKE ? ");
            updateWaitList.setInt(1,Position);
            updateWaitList.setString(2, Flight);
            updateWaitList.setString(3,Day);
            updateWaitList.executeUpdate();
            
        }catch (SQLException exception){
            exception.printStackTrace();
            System.exit(1);
            
        }
        
    }
    
    public static Boolean isOnWaitListforFlight(String PassengerName, String Date){
        
        Boolean toreturn = false;
        try{
            
            checkforEntry = DBConnection.getConnection().prepareStatement("SELECT PASSENGER FROM WAITLIST WHERE PASSENGER LIKE ? AND DATE LIKE ?");
            checkforEntry.setString(1,PassengerName);
            checkforEntry.setString(2,Date);
            resultSet = checkforEntry.executeQuery();
            if (resultSet.next()){
                
                toreturn = true;
                
            }
        }
        catch (SQLException exception){
            
            exception.printStackTrace();
            System.exit(1);
        }
        return toreturn;
        
    }
    
    public static int getWaitListLength(String Flight, String Date){
        int waitingposition = 0 ;
        
        try{
            
            selectEntries = DBConnection.getConnection().prepareStatement("SELECT COUNT(*) FROM WAITLIST WHERE FLIGHT LIKE ? AND DATE LIKE ?");
            selectEntries.setString(1, Flight);
            selectEntries.setString(2, Date);
            waitListLength = selectEntries.executeQuery();
            if(waitListLength.next()){
                waitingposition += waitListLength.getInt(1);
                
            }
            
        }
        catch(SQLException exception){
            
            exception.printStackTrace();
            System.exit(1);
        }
        
        return waitingposition; 
    }
    
}    
        
        
        
    
    
    
 
